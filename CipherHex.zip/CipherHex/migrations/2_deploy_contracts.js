const ACTPOINTSMGMT = artifacts.require("ACTPOINTSMGMT");

module.exports = function(deployer) {
  deployer.deploy(ACTPOINTSMGMT);
};